package model.objectes;

public interface Inmobiliaria {
    public void calcularImpostos();
    public void calcularComissio();
}
