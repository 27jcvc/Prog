public class ControlLlistaBuidaException extends Exception {

/// Ex2

    String missatge;

    public ControlLlistaBuidaException(String missatge) {
        this.missatge = missatge;
    }
}
