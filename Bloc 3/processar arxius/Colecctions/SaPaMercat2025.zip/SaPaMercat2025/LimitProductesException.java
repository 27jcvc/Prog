public class LimitProductesException extends Exception {
    public LimitProductesException(String message) {
        super(message);
    }
}
